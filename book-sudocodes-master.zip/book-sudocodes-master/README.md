![গ্রাফ অ্যালগোরিদম বই](https://raw.githubusercontent.com/Shafaet/book-sudocodes/master/Bookcover/bookcover.png)

This repository contains the pseudo-codes used in my **Bangla** book on Graph Algorithms.

Find the details about the book [in my blog](http://www.shafaetsplanet.com/planetcoding/?page_id=2804)

Also check these out:

* [Publishers Website](http://dimik.pub/book/104/graph-algorithm-by-shafaet-ashraf)
* [Goodreads](https://www.goodreads.com/book/show/32562667)

The book is available in Nilkhet (Haque, Rana and Manik library), also you can get home delivery from [Rokomari](https://www.rokomari.com/book/120985/).

Stay up to date by following me on [twitter](https://twitter.com/shafaet90). 
